/-  Written by `gabbro pflichten --lean`. Do not edit -- the source is the
    `.gab`, and a second register over the same thing is the very class this
    folder is written against.

    Every obligation of the register appears below: CARRIED by a theorem of
    this unit, ASSUMED (hardware, foreign code -- named in `Assumed`), or
    REFUSED by name. The line that has to add up:

        @duty 1  beispiele/03-format.gab  total 1  goals 0  refused 1
        @assumed 0  of the refused are ASSUMPTIONS -- hardware, foreign code -- and 1 are refused forms

    The meaning of a body is `Gabbro.Body`, written by hand and read by a
    person. What stands here is a DATUM of it -- this file defines nothing.

    WHAT A PERSON OWES: the `_statement` of every `_meets` and every `_keeps`
    theorem below. Each is proved by `gabbro_auto`, which closes what the
    model closes by computation and leaves a `sorry` on the rest -- and the
    rest is, by construction, the program's own logic: every hypothesis the
    proof can need stands in front of the turnstile. A person proves the
    statement in a file of their own and hands it to `unit_closed`.

    WHAT THE GENERATOR OWES, AND PAYS: the composition over every call
    (`Contract`, `Frame`), the rule of every loop (`LoopRule`), the
    precondition at every call site (the call gets stuck without it), and
    the wiring from the duties to the contracts (`unit_closed`).

    ASSUMED, and visible because it is written down: two different carrier
    names are two different objects (the alias passes carry it), and two
    objects of one record type are ONE object of the model (a record's
    places are named by its type, as a table's are); the
    declared `effects` list is complete (`E008`/`E010`, `Frame` in `Program`);
    the initial world satisfies every invariant (a statement about `boot`,
    booked by no register); and everything `Assumed` names.
-/

import Gabbro.Body

set_option autoImplicit false
set_option maxHeartbeats 11300000

open Gabbro.Body

namespace GabbroDuty.Duty03Format

/-! ## What is NOT carried, and why -/

/-
  A duty that vanishes is noticed; one that gets weaker is not -- so each
  stands here with its reason.

  layout-buffer-length (1): refused -- `lenof` over a buffer whose length no declaration gives -- `lenof` over a fixed-length array IS carried; give the parameter an array type, or drop the clause
    duty_1  N  kopf_lesen :: ensures #1
      (inherited: this clause HAS a term; the body or the `requires` of `kopf_lesen` has none)

-/

/-! ## The register, and which theorem carries each line -/

/-
  duty_1  N  kopf_lesen :: ensures #1  --  refused (layout-buffer-length)
-/

/-! ## The well-typed world -- hypothesis `U2`, once for the unit -/

/-- The shape every declared place carries, read from the declarations. -/
def shapeOf : Typing := fun p =>
  match p with
  | .field "Elf64Kopf" "e_ident_magic" => some (.intIn 1179403647 1179403647)
  | .field "Elf64Kopf" "e_typ" => some (.intIn 1 4)
  | .field "Elf64Kopf" "e_maschine" => some (.intIn 0 65535)
  | .field "Elf64Kopf" "e_version" => some (.intIn 1 1)
  | .field "Elf64Kopf" "e_eintritt" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Kopf" "e_phoff" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Kopf" "e_shoff" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Kopf" "e_ehsize" => some (.intIn 64 64)
  | .field "Elf64Kopf" "e_phentsize" => some (.intIn 56 56)
  | .field "Elf64Kopf" "e_phnum" => some (.intIn 0 65535)
  | .field "Elf64Ph" "p_typ" => some (.intIn 0 7)
  | .field "Elf64Ph" "p_flags" => some (.intIn 0 4294967295)
  | .field "Elf64Ph" "p_offset" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Ph" "p_vaddr" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Ph" "p_paddr" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Ph" "p_filesz" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Ph" "p_memsz" => some (.intIn 0 18446744073709551615)
  | .field "Elf64Ph" "p_align" => some (.intIn 0 18446744073709551615)
  | .field "Pte" "praesent" => some .bool
  | .field "Pte" "schreibbar" => some .bool
  | .field "Pte" "nutzer" => some .bool
  | .field "Pte" "pwt" => some .bool
  | .field "Pte" "pcd" => some .bool
  | .field "Pte" "benutzt" => some .bool
  | .field "Pte" "schmutzig" => some .bool
  | .field "Pte" "gross" => some .bool
  | .field "Pte" "global" => some .bool
  | .field "Pte" "rahmen" => some (.intIn 0 18446744073709551615)
  | .field "Pte" "nx" => some .bool
  | _ => none

def wellFormed (s : State) : Prop := WF shapeOf s.world

/-- **The initial state** -- what `boot` owes: a well-typed world in which every
    invariant of the unit holds. No register books it; it is named here so that it can
    be assumed BY NAME and not by omission. -/
def Initially (s0 : State) : Prop :=
  wellFormed s0

/-- **What is assumed of the environment beyond the bodies of this unit.** -/
def Assumed (ρ : Env) : Prop :=
  True

/-! ## The routines: body and contract -/

/-! ### `kopf_lesen` -/

-- REFUSED  kopf_lesen  (layout-buffer-length): `lenof` over a buffer whose length no declaration gives -- `lenof` over a fixed-length array IS carried; give the parameter an array type, or drop the clause
--   Its contract stands below all the same, so that a caller's theorem can name it;
--   what is missing is the theorem that discharges it.

/-- The precondition: the declared shapes and the `requires`. -/
def kopf_lesen_pre : Expr :=
  (.lit (.bool true))

def kopf_lesen_writes : List String := []

/-- What a caller of `kopf_lesen` has to bring: a well-typed world and the precondition. -/
def kopf_lesen_requires (t : State) : Prop := wellFormed t ∧ eval t kopf_lesen_pre = some (.bool true)

/-- What `kopf_lesen` PROMISES: the world stays well-typed, every invariant it maintains
    survives, and its `ensures` hold -- over the entry state (`old`), the exit state
    and the result. -/
def kopf_lesen_post (s s' : State) (r : Option Value) : Prop :=
  wellFormed s'
  ∧ -- the answer: a value of the declared shape
  (∃ x, r = some (.int x) ∧ 0 ≤ x ∧ x ≤ 18446744073709551615)
  ∧ -- ensures #1
  (∃ v, r = some v ∧ eval { world := s'.world, local' := (bindLocal s.local' "result" v) } (.bin .eq (.name "result") (.fieldOf "Elf64Kopf" "e_eintritt")) = some (.bool true))

/-! ## The duties: one statement per routine and per loop -/

/-! ## The wiring -- what the generator owes, and pays

    `Program ρ` says the environment runs the bodies of this unit. From it and
    the duty statements, `unit_closed` yields every contract and every loop rule
    -- in dependency order, so that no person writes the induction over the
    call graph or over the passes of a loop. -/

def Program (ρ : Env) : Prop :=
  True

theorem unit_closed (ρ : Env) (hp : Program ρ) (ha : Assumed ρ) :
    True := by
  trivial

end GabbroDuty.Duty03Format
