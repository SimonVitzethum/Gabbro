/-  Written by `gabbro pflichten --lean`. Do not edit -- the source is the
    `.gab`, and a second register over the same thing is the very class this
    folder is written against.

    Every obligation of the register appears below: CARRIED by a theorem of
    this unit, ASSUMED (hardware, foreign code -- named in `Assumed`), or
    REFUSED by name. The line that has to add up:

        @duty 1  arbeitsprotokoll/messungen/rennen-5-gesperrt.gab  total 0  goals 0  refused 0
        @assumed 0  of the refused are ASSUMPTIONS -- hardware, foreign code -- and 0 are refused forms

    The meaning of a body is `Gabbro.Body`, written by hand and read by a
    person. What stands here is a DATUM of it -- this file defines nothing.

    WHAT A PERSON OWES: the `_statement` of every `_meets` and every `_keeps`
    theorem below. Each is proved by `gabbro_auto`, which closes what the
    model closes by computation and leaves a `sorry` on the rest -- and the
    rest is, by construction, the program's own logic: every hypothesis the
    proof can need stands in front of the turnstile. A person proves the
    statement in a file of their own and hands it to `unit_closed`.

    WHAT THE GENERATOR OWES, AND PAYS: the composition over every call
    (`Contract`, `Frame`), the rule of every loop (`LoopRule`), the
    precondition at every call site (the call gets stuck without it), and
    the wiring from the duties to the contracts (`unit_closed`).

    ASSUMED, and visible because it is written down: two different carrier
    names are two different objects (the alias passes carry it), and two
    objects of one record type are ONE object of the model (a record's
    places are named by its type, as a table's are); the
    declared `effects` list is complete (`E008`/`E010`, `Frame` in `Program`);
    the initial world satisfies every invariant (a statement about `boot`,
    booked by no register); and everything `Assumed` names.
-/

import Gabbro.Body

set_option autoImplicit false
set_option maxHeartbeats 11300000

open Gabbro.Body

namespace GabbroDuty.DutyRennen5Gesperrt

/-! ## What is NOT carried, and why -/

-- Every obligation of this unit is carried by a theorem below.

/-! ## The register, and which theorem carries each line -/

/-
-/

/-! ## The well-typed world -- hypothesis `U2`, once for the unit -/

/-- The shape every declared place carries, read from the declarations. -/
def shapeOf : Typing := fun p =>
  match p with
  | .global "zaehler" => some (.intIn 0 4294967295)
  | _ => none

def wellFormed (s : State) : Prop := WF shapeOf s.world

/-- **The initial state** -- what `boot` owes: a well-typed world in which every
    invariant of the unit holds. No register books it; it is named here so that it can
    be assumed BY NAME and not by omission. -/
def Initially (s0 : State) : Prop :=
  wellFormed s0

/-- **What is assumed of the environment beyond the bodies of this unit.** -/
def Assumed (ρ : Env) : Prop :=
  True

/-! ## The routines: body and contract -/

/-! ### `a` -/

def a_body : List Stmt :=
  [(.locked "L" [(.assignGlobal "zaehler" (.lit (.int 1)))])]

/-- The precondition: the declared shapes and the `requires`. -/
def a_pre : Expr :=
  (.lit (.bool true))

def a_writes : List String := ["zaehler"]

/-- What a caller of `a` has to bring: a well-typed world and the precondition. -/
def a_requires (t : State) : Prop := wellFormed t ∧ eval t a_pre = some (.bool true)

/-- What `a` PROMISES: the world stays well-typed, every invariant it maintains
    survives, and its `ensures` hold -- over the entry state (`old`), the exit state
    and the result. -/
def a_post (s s' : State) (r : Option Value) : Prop :=
  wellFormed s'

/-! ### `b` -/

def b_body : List Stmt :=
  [(.locked "L" [(.assignGlobal "zaehler" (.lit (.int 2)))])]

/-- The precondition: the declared shapes and the `requires`. -/
def b_pre : Expr :=
  (.lit (.bool true))

def b_writes : List String := ["zaehler"]

/-- What a caller of `b` has to bring: a well-typed world and the precondition. -/
def b_requires (t : State) : Prop := wellFormed t ∧ eval t b_pre = some (.bool true)

/-- What `b` PROMISES: the world stays well-typed, every invariant it maintains
    survives, and its `ensures` hold -- over the entry state (`old`), the exit state
    and the result. -/
def b_post (s s' : State) (r : Option Value) : Prop :=
  wellFormed s'

/-! ## The duties: one statement per routine and per loop -/

/-! ### `a` -/

/-- **The duty of `a`**: under its precondition, the body runs to an end and
    keeps its promise. Every `ensures`, every `V` at its call sites and every
    invariant it maintains is this one theorem. -/
def a_meets_statement : Prop :=
  ∀ (ρ : Env) (s : State)
    -- the well-formed world (`U2`)
    (hwf : wellFormed s)
    -- the declared shapes, the `requires`, the invariants it maintains
    (hpre : eval s a_pre = some (.bool true)),
    ∃ s', finalState (exec ρ a_body s) = some s'
        ∧ a_post s s' (finalValue (exec ρ a_body s))

theorem a_meets : a_meets_statement := by
  unfold a_meets_statement
  intro ρ s hwf hpre
  simp only [wellFormed] at hwf ⊢
  have hall := hpre
  gabbro_simp_at hall [a_pre]
  gabbro_auto [a_body, a_pre, a_post, wellFormed, hall] using shapeOf

/-! ### `b` -/

/-- **The duty of `b`**: under its precondition, the body runs to an end and
    keeps its promise. Every `ensures`, every `V` at its call sites and every
    invariant it maintains is this one theorem. -/
def b_meets_statement : Prop :=
  ∀ (ρ : Env) (s : State)
    -- the well-formed world (`U2`)
    (hwf : wellFormed s)
    -- the declared shapes, the `requires`, the invariants it maintains
    (hpre : eval s b_pre = some (.bool true)),
    ∃ s', finalState (exec ρ b_body s) = some s'
        ∧ b_post s s' (finalValue (exec ρ b_body s))

theorem b_meets : b_meets_statement := by
  unfold b_meets_statement
  intro ρ s hwf hpre
  simp only [wellFormed] at hwf ⊢
  have hall := hpre
  gabbro_simp_at hall [b_pre]
  gabbro_auto [b_body, b_pre, b_post, wellFormed, hall] using shapeOf

/-! ## The wiring -- what the generator owes, and pays

    `Program ρ` says the environment runs the bodies of this unit. From it and
    the duty statements, `unit_closed` yields every contract and every loop rule
    -- in dependency order, so that no person writes the induction over the
    call graph or over the passes of a loop. -/

def Program (ρ : Env) : Prop :=
  Runs ρ "a" a_body
  ∧ Frame ρ "a" a_writes
  ∧ Runs ρ "b" b_body
  ∧ Frame ρ "b" b_writes

theorem unit_closed (ρ : Env) (hp : Program ρ) (ha : Assumed ρ)
    (d_a : a_meets_statement)
    (d_b : b_meets_statement) :
    Contract ρ "a" a_requires a_post
    ∧ Contract ρ "b" b_requires b_post := by
  obtain ⟨r_a, fr_a, r_b, fr_b⟩ := hp
  have c_a : Contract ρ "a" a_requires a_post :=
    contract_of_duty ρ "a" a_body a_requires a_post r_a
      (fun t ht => d_a ρ t ht.1 ht.2)
  have c_b : Contract ρ "b" b_requires b_post :=
    contract_of_duty ρ "b" b_body b_requires b_post r_b
      (fun t ht => d_b ρ t ht.1 ht.2)
  exact ⟨c_a, c_b⟩

end GabbroDuty.DutyRennen5Gesperrt
