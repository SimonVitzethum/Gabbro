/-  Written by `gabbro pflichten --lean`. Do not edit -- the source is the
    `.gab`, and a second register over the same thing is the very class this
    folder is written against.

    Every obligation of the register appears below: CARRIED by a theorem of
    this unit, ASSUMED (hardware, foreign code -- named in `Assumed`), or
    REFUSED by name. The line that has to add up:

        @duty 1  messungen/tabelle.gab  total 0  goals 0  refused 0
        @assumed 0  of the refused are ASSUMPTIONS -- hardware, foreign code -- and 0 are refused forms

    The meaning of a body is `Gabbro.Body`, written by hand and read by a
    person. What stands here is a DATUM of it -- this file defines nothing.

    WHAT A PERSON OWES: the `_statement` of every `_meets` and every `_keeps`
    theorem below. Each is proved by `gabbro_auto`, which closes what the
    model closes by computation and leaves a `sorry` on the rest -- and the
    rest is, by construction, the program's own logic: every hypothesis the
    proof can need stands in front of the turnstile. A person proves the
    statement in a file of their own and hands it to `unit_closed`.

    WHAT THE GENERATOR OWES, AND PAYS: the composition over every call
    (`Contract`, `Frame`), the rule of every loop (`LoopRule`), the
    precondition at every call site (the call gets stuck without it), and
    the wiring from the duties to the contracts (`unit_closed`).

    ASSUMED, and visible because it is written down: two different carrier
    names are two different objects (the alias passes carry it), and two
    objects of one record type are ONE object of the model (a record's
    places are named by its type, as a table's are); the
    declared `effects` list is complete (`E008`/`E010`, `Frame` in `Program`);
    the initial world satisfies every invariant (a statement about `boot`,
    booked by no register); and everything `Assumed` names.
-/

import Gabbro.Body

set_option autoImplicit false
set_option maxHeartbeats 11300000

open Gabbro.Body

namespace GabbroDuty.DutyTabelle

/-! ## What is NOT carried, and why -/

-- Every obligation of this unit is carried by a theorem below.

/-! ## The register, and which theorem carries each line -/

/-
-/

/-! ## The well-typed world -- hypothesis `U2`, once for the unit -/

/-- The shape every declared place carries, read from the declarations. -/
def shapeOf : Typing := fun p =>
  match p with
  | .slot "Objekte" _ "benutzt" => some .bool
  | .slot "Objekte" _ "zaehler" => some (.intIn 0 4294967295)
  | _ => none

def wellFormed (s : State) : Prop := WF shapeOf s.world

/-- **The initial state** -- what `boot` owes: a well-typed world in which every
    invariant of the unit holds. No register books it; it is named here so that it can
    be assumed BY NAME and not by omission. -/
def Initially (s0 : State) : Prop :=
  wellFormed s0

/-- **What is assumed of the environment beyond the bodies of this unit.** -/
def Assumed (ρ : Env) : Prop :=
  True

/-! ## The routines: body and contract -/

/-! ### `belegen` -/

def belegen_body : List Stmt :=
  [(.assign "Objekte" (.name "i") "benutzt" (.lit (.bool true)))]

/-- The precondition: the declared shapes and the `requires`. -/
def belegen_pre : Expr :=
  (.hasShape "i" (.intIn 0 4095))

def belegen_writes : List String := ["Objekte"]

/-- What a caller of `belegen` has to bring: a well-typed world and the precondition. -/
def belegen_requires (t : State) : Prop := wellFormed t ∧ eval t belegen_pre = some (.bool true)

/-- What `belegen` PROMISES: the world stays well-typed, every invariant it maintains
    survives, and its `ensures` hold -- over the entry state (`old`), the exit state
    and the result. -/
def belegen_post (s s' : State) (r : Option Value) : Prop :=
  wellFormed s'

/-! ### `stand` -/

def stand_body : List Stmt :=
  [(.ret (some (.place "Objekte" (.name "i") "zaehler")))]

/-- The precondition: the declared shapes and the `requires`. -/
def stand_pre : Expr :=
  (.hasShape "i" (.intIn 0 4095))

def stand_writes : List String := []

/-- What a caller of `stand` has to bring: a well-typed world and the precondition. -/
def stand_requires (t : State) : Prop := wellFormed t ∧ eval t stand_pre = some (.bool true)

/-- What `stand` PROMISES: the world stays well-typed, every invariant it maintains
    survives, and its `ensures` hold -- over the entry state (`old`), the exit state
    and the result. -/
def stand_post (s s' : State) (r : Option Value) : Prop :=
  wellFormed s'
  ∧ -- the answer: a value of the declared shape
  (∃ x, r = some (.int x) ∧ 0 ≤ x ∧ x ≤ 4294967295)

/-! ## The duties: one statement per routine and per loop -/

/-! ### `belegen` -/

/-- **The duty of `belegen`**: under its precondition, the body runs to an end and
    keeps its promise. Every `ensures`, every `V` at its call sites and every
    invariant it maintains is this one theorem. -/
def belegen_meets_statement : Prop :=
  ∀ (ρ : Env) (s : State)
    -- the well-formed world (`U2`)
    (hwf : wellFormed s)
    -- the declared shapes, the `requires`, the invariants it maintains
    (hpre : eval s belegen_pre = some (.bool true)),
    ∃ s', finalState (exec ρ belegen_body s) = some s'
        ∧ belegen_post s s' (finalValue (exec ρ belegen_body s))

theorem belegen_meets : belegen_meets_statement := by
  unfold belegen_meets_statement
  intro ρ s hwf hpre
  simp only [wellFormed] at hwf ⊢
  obtain ⟨w_i, e_i, lo_i, hi_i⟩ := shape_intIn s "i" _ _ hpre
  have hall := hpre
  gabbro_simp_at hall [belegen_pre, e_i]
  gabbro_auto [belegen_body, belegen_pre, belegen_post, wellFormed, e_i, hall] using shapeOf

/-! ### `stand` -/

/-- **The duty of `stand`**: under its precondition, the body runs to an end and
    keeps its promise. Every `ensures`, every `V` at its call sites and every
    invariant it maintains is this one theorem. -/
def stand_meets_statement : Prop :=
  ∀ (ρ : Env) (s : State)
    -- the well-formed world (`U2`)
    (hwf : wellFormed s)
    -- the declared shapes, the `requires`, the invariants it maintains
    (hpre : eval s stand_pre = some (.bool true)),
    ∃ s', finalState (exec ρ stand_body s) = some s'
        ∧ stand_post s s' (finalValue (exec ρ stand_body s))

theorem stand_meets : stand_meets_statement := by
  unfold stand_meets_statement
  intro ρ s hwf hpre
  simp only [wellFormed] at hwf ⊢
  obtain ⟨w_i, e_i, lo_i, hi_i⟩ := shape_intIn s "i" _ _ hpre
  obtain ⟨n_Objekte_zaehler_i, h_Objekte_zaehler_i, lo_Objekte_zaehler_i, hi_Objekte_zaehler_i⟩ := WF_intIn shapeOf s.world (.slot "Objekte" w_i "zaehler") _ _ hwf rfl
  have hall := hpre
  gabbro_simp_at hall [stand_pre, e_i, h_Objekte_zaehler_i]
  gabbro_auto [stand_body, stand_pre, stand_post, wellFormed, e_i, h_Objekte_zaehler_i, hall] using shapeOf

/-! ## The wiring -- what the generator owes, and pays

    `Program ρ` says the environment runs the bodies of this unit. From it and
    the duty statements, `unit_closed` yields every contract and every loop rule
    -- in dependency order, so that no person writes the induction over the
    call graph or over the passes of a loop. -/

def Program (ρ : Env) : Prop :=
  Runs ρ "belegen" belegen_body
  ∧ Frame ρ "belegen" belegen_writes
  ∧ Runs ρ "stand" stand_body
  ∧ Frame ρ "stand" stand_writes

theorem unit_closed (ρ : Env) (hp : Program ρ) (ha : Assumed ρ)
    (d_belegen : belegen_meets_statement)
    (d_stand : stand_meets_statement) :
    Contract ρ "belegen" belegen_requires belegen_post
    ∧ Contract ρ "stand" stand_requires stand_post := by
  obtain ⟨r_belegen, fr_belegen, r_stand, fr_stand⟩ := hp
  have c_belegen : Contract ρ "belegen" belegen_requires belegen_post :=
    contract_of_duty ρ "belegen" belegen_body belegen_requires belegen_post r_belegen
      (fun t ht => d_belegen ρ t ht.1 ht.2)
  have c_stand : Contract ρ "stand" stand_requires stand_post :=
    contract_of_duty ρ "stand" stand_body stand_requires stand_post r_stand
      (fun t ht => d_stand ρ t ht.1 ht.2)
  exact ⟨c_belegen, c_stand⟩

end GabbroDuty.DutyTabelle
